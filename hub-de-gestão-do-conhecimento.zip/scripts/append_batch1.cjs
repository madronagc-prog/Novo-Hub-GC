const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, '../public/banco_de_clausulas.csv');

// We have the raw CSV in /src/data/clausulas_data.csv for the first 4 rows already!
// Let's copy /src/data/clausulas_data.csv to public/banco_de_clausulas.csv
if (fs.existsSync(path.join(__dirname, '../src/data/clausulas_data.csv'))) {
  fs.copyFileSync(path.join(__dirname, '../src/data/clausulas_data.csv'), target);
  console.log("Copied initial 4 rows");
}
