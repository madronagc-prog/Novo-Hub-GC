const fs = require('fs');

// We have the raw CSV in the prompt. Let's create an input file with the CSV content.
