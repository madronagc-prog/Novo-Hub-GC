const fs = require('fs');

console.log("Creating clause builder");
