const fs = require('fs');
const path = require('path');

// Let's create an append helper to build public/banco_de_clausulas_data.csv
const targetCsv = path.join(__dirname, '../public/banco_de_clausulas_data.csv');

module.exports = { targetCsv };
