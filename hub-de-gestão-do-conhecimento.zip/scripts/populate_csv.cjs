const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../public/banco_de_clausulas.csv');

// Header
fs.writeFileSync(filePath, 'Título,Texto Original,Texto normalizado 1C 1V,Texto normalizado 1C 2V,Texto normalizado 2C 1V,Texto normalizado 2C 2V,Texto traduzido 1C 1V,Texto traduzido 1C 2V,Texto traduzido 2C 1V,Texto traduzido 2C 2V,Idioma Original,Tipo de Cláusula,Subtipo,Contexto de Uso,Pontos de Atenção,Definições Utilizadas,Posição Negocial,Posicao Negocial,Tags Conceituais,Observação,Selo,Status,Contador de Cópias,Contribuidor,Aprovador,Data de Aprovação,Substitui,Tipo de Documento,Tipo de Item,Caminho\n', 'utf8');

console.log("Initialized CSV");
